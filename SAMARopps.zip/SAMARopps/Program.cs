﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{

    public class Employee
    {
        public string EmpId { get; set; }
        public string Name { get; set; }

        public virtual decimal CalculatePay()
        {
            return 0;
        }
    }


    public class Salaried : Employee
    {
        public decimal Salary { get; set; }

        public override decimal CalculatePay()
        {
            return Salary / 52;
        }
    }


    public class PartTime : Employee
    {
        public decimal HoursWorked { get; set; }
        public decimal HourlyRate { get; set; }

        public override decimal CalculatePay()
        {
            return HoursWorked * HourlyRate;
        }
    }


    public class Wages : Employee
    {
        public decimal HoursWorked { get; set; }
        public decimal HourlyRate { get; set; }
        public decimal OvertimeHours { get; set; }

        public override decimal CalculatePay()
        {
            decimal normalPay = HoursWorked * HourlyRate;
            decimal overtimePay = OvertimeHours * (HourlyRate * 1.5m);
            return normalPay + overtimePay;
        }
    }


    public class PayrollApplication
    {
        private List<Employee> employees;

        public PayrollApplication()
        {
            employees = new List<Employee>();
        }

        public void FillEmployeeList(string filename)
        {
            using (StreamReader employees = new StreamReader(employees.txt))
            {
                string line;
                while ((line = employees.ReadLine()) != null)
                {
                    string[] data = line.Split(',');
                    string empId = data[0];
                    string name = data[1];
                    string empType = data[2];
                    if (empType == "Salaried")
                    {
                        decimal salary = decimal.Parse(data[3]);
                        Employee employee = new Salaried { EmpId = empId, Name = name, Salary = salary };
                        employees.Add(employee);
                    }
                    else if (empType == "PartTime")
                    {
                        decimal hoursWorked = decimal.Parse(data[3]);
                        decimal hourlyRate = decimal.Parse(data[4]);
                        Employee employee = new PartTime { EmpId = empId, Name = name, HoursWorked = hoursWorked, HourlyRate = hourlyRate };
                        employees.Add(employee);
                    }
                    else if (empType == "Wages")
                    {
                        decimal hoursWorked = decimal.Parse(data[3]);
                        decimal hourlyRate = decimal.Parse(data[4]);
                        decimal overtimeHours = decimal.Parse(data[5]);
                        Employee employee = new Wages { EmpId = empId, Name = name, HoursWorked = hoursWorked, HourlyRate = hourlyRate, OvertimeHours = overtimeHours };
                        employees.Add(employee);
                    }
                }
            }
        }

        public decimal CalculateAverageWeeklyPay()
        {
            decimal totalPay = 0;
            foreach (Employee employee in employees)
            {
                totalPay += employee.CalculatePay();
            }
            return totalPay / employees.Count;
        }

        public Tuple<decimal, string> CalculateHighestWeeklyPay()
        {
            decimal highestPay = 0;
            string employeeName = "";
            foreach (Employee employee in employees)
            {
                decimal weeklyPay = employee.CalculatePay();
                if (weeklyPay > highestPay)
                {
                    highestPay = weeklyPay;
                    employeeName = employee.Name;
                }
            }
            return new Tuple<decimal, string>(highestPay, employeeName);
        }

        public Tuple<decimal, string> CalculateLowestSalary()
        {
            decimal lowestSalary = decimal.MaxValue;
            string employeeName = "";
            foreach (Employee employee in employees)
            {
                if (employee is Salaried salariedEmployee)
                {
                    if (salariedEmployee.Salary < lowestSalary)
                    {
                        lowestSalary = salariedEmployee.Salary;
                        employeeName = salariedEmployee.Name;
                    }
                }
            }
            return new Tuple<decimal, string>(lowestSalary, employeeName);
        }

        public Dictionary<string, decimal> CalculateEmployeeCategoryPercentage()
        {
            Dictionary<string, decimal> categoryPercentage = new Dictionary<string, decimal>();
            int totalEmployees = employees.Count;
            int salariedCount = employees.Count(e => e is Salaried);
            int partTimeCount = employees.Count(e => e is PartTime);
            int wagesCount = employees.Count(e => e is Wages);

            categoryPercentage.Add("Salaried", (decimal)salariedCount / totalEmployees * 100);
            categoryPercentage.Add("PartTime", (decimal)partTimeCount / totalEmployees * 100);
            categoryPercentage.Add("Wages", (decimal)wagesCount / totalEmployees * 100);

            return categoryPercentage;
        }
    }


    public class Program
    {
        public static void Main(string[] args)
        {
            PayrollApplication payrollApp = new PayrollApplication();
            payrollApp.FillEmployeeList("res/employees.txt");

            decimal averageWeeklyPay = payrollApp.CalculateAverageWeeklyPay();
            Console.WriteLine("Average Weekly Pay: " + averageWeeklyPay);

            Tuple<decimal, string> highestWeeklyPay = payrollApp.CalculateHighestWeeklyPay();
            Console.WriteLine("Highest Weekly Pay: " + highestWeeklyPay.Item1 + " (Employee: " + highestWeeklyPay.Item2 + ")");

            Tuple<decimal, string> lowestSalary = payrollApp.CalculateLowestSalary();
            Console.WriteLine("Lowest Salary: " + lowestSalary.Item1 + " (Employee: " + lowestSalary.Item2 + ")");

            Dictionary<string, decimal> categoryPercentage = payrollApp.CalculateEmployeeCategoryPercentage();
            foreach (KeyValuePair<string, decimal> entry in categoryPercentage)
            {
                Console.WriteLine(entry.Key + " Percentage: " + entry.Value + "%");
            }
        }
    }

}
